from datetime import datetime

OptionalString = str | None
OptionalInteger = int | None
OptionalFloat = float | None
OptionalBoolean = bool | None
OptionalDatetime = datetime | None
